from telethon import TelegramClient, events
import os
import json
import re
import asyncio
import logging
import sqlite3
from typing import Dict, Optional, List
from dotenv import load_dotenv
from ratelimit import limits, sleep_and_retry
from datetime import datetime
import telethon.errors
import google.generativeai as genai
import time
import traceback
import signal

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()
API_ID = int(os.getenv('TELEGRAM_API_ID', '28110628'))
API_HASH = os.getenv('TELEGRAM_API_HASH', '5e8fa6b7ee85ab1539fa664ba5422bf8')
SESSION_NAME = os.getenv('TELEGRAM_SESSION_NAME', 'Deploy')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', 'AIzaSyBMOoAxdgbzU2bOew3DuuRYOI_6gU_iU04')
GEMINI_MODEL = "gemini-2.0-flash-thinking-exp-01-21"

# SQLite database setup
DB_FILE = 'cards.db'

# Add this global variable to track shutdown state
is_shutting_down = False

def init_db():
    """Initialize SQLite database and create tables if they don't exist."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS cards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id TEXT UNIQUE,
            card_number TEXT,
            provider TEXT,
            units TEXT,
            card_date TEXT,
            source_channel TEXT,
            forwarded_at TEXT
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS channels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel_name TEXT UNIQUE,
            is_source INTEGER
        )
    ''')
    
    c.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    
    defaults = [
        ('delete_timeout', '120'),
        ('emojis', '{"vodafone": "🔴", "we": "🟣", "orange": "🟠"}')
    ]
    c.executemany('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', defaults)
    
    conn.commit()
    conn.close()

# Initialize client first to use in config loading
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

# Initialize global variables with default values
SOURCE_CHANNELS = []
DESTINATION_CHANNEL = ""
DELETE_TIMEOUT = 120
EMOJIS = {"vodafone": "🔴", "we": "🟣", "orange": "🟠"}

# Configure Gemini AI
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
else:
    logger.error("Gemini API key not set. Units extraction will rely solely on regex.")
    GEMINI_API_KEY = None

# Compiled regex patterns
EMBEDDED_CARD_PATTERN = re.compile(r'#(\d+)\*858\*')  # Embedded cards
MULTI_CARD_PATTERN = re.compile(r'(\d{13,15})\s*\n\s*(\d{2,4})')  # Multi-card with units on next line
VODAFONE_PATTERN = re.compile(r'(\*858\*(\d{13})#)')  # Vodafone USSD
WE_PATTERN = re.compile(r'(\*015\*(\d{15})#)')  # WE USSD
ORANGE_PATTERN = re.compile(r'(\*10\*(\d{13})#)')  # Orange USSD
RAW_CARD_PATTERN = re.compile(r'\b(\d{13,15})\b')  # Raw card numbers
UNITS_PATTERN = re.compile(r'(?:وحدة|وحده|وحدات|unit|value|VALUE|units)\s*:?\s*(\d{2,4})\b', re.IGNORECASE)
SIMPLE_UNITS_PATTERN = re.compile(r'\b(\d{2,4})\b')  # Simple 2-4 digit numbers for units

# Create a global dictionary to track pending validations
pending_validations = {}

def format_response(provider: str, card_number: str, units: str) -> str:
    """Format the response message with emojis and card details."""
    # Define provider emojis
    provider_emojis = {
        "Vodafone": "🔴",
        "WE": "🟣",
        "Orange": "🟠"
    }
    
    emoji = provider_emojis.get(provider, "")
    
    # For WE cards, show "Charges: 5" instead of units
    if provider == "WE":
        units_line = "🔄 Charges: 5"  # Fixed value of 5 for WE cards
    else:
        units_line = f"📶 Units: {units}"
    
    # Format the message
    return (
        f"▂▂▂ {emoji} {provider} Card {emoji} ▂▂▂\n\n"
        f"✅ Code: {card_number}\n\n"
        f"{units_line}\n\n"
        f"📅 Card Date: {datetime.now().strftime('%Y-%m-%d')}\n"
        f"▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂"
    )

async def determine_provider_and_format(text: str, source_channel: str, chat_id: str) -> Optional[List[Dict]]:
    """Extract card data, try regex for units, fall back to Gemini if needed."""
    lines = text.split('\n')
    formatted_responses = []
    
    # Check for Orange sharing pattern first
    orange_sharing_match = re.search(r'ابعت\s+(\d+)\s+ميجا\s+ل(\d+)', text, re.DOTALL)
    if orange_sharing_match:
        total_units = int(orange_sharing_match.group(1))
        num_friends = int(orange_sharing_match.group(2))
        per_person_units = total_units // num_friends
        
        logger.info(f"Orange sharing detected: {total_units} units for {num_friends} friends = {per_person_units} per person")
        
        # Now find the card number
        orange_code_match = re.search(r'#10\*(\d+)#', text)
        if orange_code_match:
            raw_number = orange_code_match.group(1)
            card_number = f"*10*{raw_number}#"
            formatted_responses.append({
                "provider": "Orange",
                "card_number": card_number,
                "units": str(per_person_units),
                "text": format_response("Orange", card_number, str(per_person_units)),
                "source_channel": source_channel
            })
            return formatted_responses
    
    # Check for Vodafone sharing pattern
    vodafone_sharing_match = re.search(r'(\d+)\s+ليك\s+يعني\s+(\d+)\s+وحدة\s+(\d+)\s+ضعف\s+تبعتهم\s+ل(\d+)', text, re.DOTALL)
    if vodafone_sharing_match:
        user_multiplier = int(vodafone_sharing_match.group(1))
        user_units = int(vodafone_sharing_match.group(2))
        friends_multiplier = int(vodafone_sharing_match.group(3))
        num_friends = int(vodafone_sharing_match.group(4))
        
        # Calculate base unit value
        base_unit = user_units // user_multiplier
        
        # Calculate per friend units
        per_friend_multiplier = friends_multiplier // num_friends
        per_friend_units = per_friend_multiplier * base_unit
        
        logger.info(f"Vodafone sharing detected: Base unit={base_unit}, Per friend units={per_friend_units}")
        
        # Find the card number
        vodafone_code_match = re.search(r'#(\d+)\*858\*', text)
        if vodafone_code_match:
            raw_number = vodafone_code_match.group(1)
            card_number = f"*858*{raw_number}#"
            formatted_responses.append({
                "provider": "Vodafone",
                "card_number": card_number,
                "units": str(per_friend_units),
                "text": format_response("Vodafone", card_number, str(per_friend_units)),
                "source_channel": source_channel
            })
            return formatted_responses
    
    # Check for direct Vodafone units pattern
    direct_vodafone_match = re.search(r'معاك\s+(\d+)\s+وحدة\s+من\s+كارت\s+فودافون', text, re.DOTALL)
    if direct_vodafone_match:
        raw_units = int(direct_vodafone_match.group(1))
        
        # Apply the special calculation for this type of message: value * 5 / 50
        calculated_units = str(int((raw_units * 5) / 50))
        
        logger.info(f"Direct Vodafone units detected: {raw_units} → calculated to {calculated_units}")
        
        # Find the card number
        vodafone_code_match = re.search(r'#(\d+)\*858\*', text)
        if vodafone_code_match:
            raw_number = vodafone_code_match.group(1)
            card_number = f"*858*{raw_number}#"
            formatted_responses.append({
                "provider": "Vodafone",
                "card_number": card_number,
                "units": calculated_units,
                "text": format_response("Vodafone", card_number, calculated_units),
                "source_channel": source_channel
            })
            return formatted_responses
    
    # Continue with regular line-by-line processing
    for i, line in enumerate(lines):
        if vodafone_match := VODAFONE_PATTERN.search(line):
            card_number, raw_number = vodafone_match.groups()
            units = extract_units_near_card(lines, i)
            if units == "Unknown":
                units = "Validating..."
            formatted_responses.append({
                "provider": "Vodafone",
                "card_number": card_number,
                "units": units,
                "text": format_response("Vodafone", card_number, units),
                "source_channel": source_channel
            })
    
        elif we_match := WE_PATTERN.search(line):
            card_number, raw_number = we_match.groups()
            units = extract_units_near_card(lines, i)
            if units == "Unknown":
                units = "Validating..."
            formatted_responses.append({
                "provider": "WE",
                "card_number": card_number,
                "units": units,
                "text": format_response("WE", card_number, units),
                "source_channel": source_channel
            })
    
        elif orange_match := ORANGE_PATTERN.search(line):
            card_number, raw_number = orange_match.groups()
            units = extract_units_near_card(lines, i)
            if units == "Unknown":
                units = "Validating..."
            formatted_responses.append({
                "provider": "Orange",
                "card_number": card_number,
                "units": units,
                "text": format_response("Orange", card_number, units),
                "source_channel": source_channel
            })
        
        # Add a new pattern for Orange cards with #10* format
        elif "#10*" in line:
            # Extract the card number after #10*
            orange_code_match = re.search(r'#10\*(\d+)#', line)
            if orange_code_match:
                raw_number = orange_code_match.group(1)
                card_number = f"*10*{raw_number}#"
                units = extract_units_near_card(lines, i)
                if units == "Unknown":
                    units = "Validating..."
                formatted_responses.append({
                    "provider": "Orange",
                    "card_number": card_number,
                    "units": units,
                    "text": format_response("Orange", card_number, units),
                    "source_channel": source_channel
                })
    
        # Embedded pattern (assumed Vodafone)
        elif embedded_match := EMBEDDED_CARD_PATTERN.search(line):
            raw_number = embedded_match.group(1)
            card_number = f"*858*{raw_number}#"
            units = extract_units_near_card(lines, i)
            if units == "Unknown":
                units = "Validating..."
            formatted_responses.append({
                "provider": "Vodafone",
                "card_number": card_number,
                "units": units,
                "text": format_response("Vodafone", card_number, units),
                "source_channel": source_channel
            })
    
        # Raw numbers
        elif raw_match := RAW_CARD_PATTERN.search(line):
            raw_number = raw_match.group(1)
            if len(raw_number) == 13:
                card_number = f"*858*{raw_number}#"
                provider = "Vodafone"
            elif len(raw_number) == 15:
                card_number = f"*015*{raw_number}#"
                provider = "WE"
            else:
                continue
            units = extract_units_near_card(lines, i)
            if units == "Unknown":
                units = "Validating..."
            formatted_responses.append({
                "provider": provider,
                "card_number": card_number,
                "units": units,
                "text": format_response(provider, card_number, units),
                "source_channel": source_channel
            })
    
    # Handle multi-card pattern as a fallback
    multi_matches = MULTI_CARD_PATTERN.findall(text)
    for raw_number, units in multi_matches:
        card_number = f"*858*{raw_number}#"
        formatted_responses.append({
            "provider": "Vodafone",
            "card_number": card_number,
            "units": units,
            "text": format_response("Vodafone", card_number, units),
            "source_channel": source_channel
        })
    
    return formatted_responses if formatted_responses else None

def extract_units_near_card(lines: List[str], card_line_index: int) -> str:
    """Extract units from lines near the card number."""
    # Check current line and 2 lines before/after for units
    start_idx = max(0, card_line_index - 2)
    end_idx = min(len(lines), card_line_index + 3)
    
    for i in range(start_idx, end_idx):
        line = lines[i]
        
        # Check for units patterns
        if units_match := UNITS_PATTERN.search(line):
            return units_match.group(1)
        
        # Check for raw number that might be units
        if raw_units_match := re.search(r'^\s*(\d{2,4})\s*$', line):
            units = raw_units_match.group(1)
            if 50 <= int(units) <= 15000:
                return units
    
    return "Unknown"

async def start_validation_timer(sent_message_id: int, card_number: str, chat_id: str, provider: str):
    """Start a timer to validate units for a message."""
    global pending_validations
    
    try:
        logger.info(f"Starting validation timer for card {card_number}")
        
        pending_validations[card_number] = {
            "message_id": sent_message_id,
            "start_time": time.time(),
            "provider": provider
        }
        
        # Run the validation check directly
        await check_for_units(card_number, chat_id)
    except Exception as e:
        logger.error(f"Error in start_validation_timer: {e}")
        logger.error(traceback.format_exc())

async def check_for_units(card_number: str, chat_id: str):
    """Check for units in subsequent messages for up to 60 seconds."""
    global pending_validations
    
    if card_number not in pending_validations:
        logger.error(f"Card {card_number} not found in pending validations")
        return
        
    start_time = pending_validations[card_number]["start_time"]
    message_id = pending_validations[card_number]["message_id"]
    provider = pending_validations[card_number]["provider"]
    
    logger.info(f"Starting unit check for card {card_number}")
    
    # Wait for up to 60 seconds, checking every 5 seconds
    end_time = start_time + 60
    
    while time.time() < end_time:
        try:
            # Get recent messages (last 20)
            recent_messages = await client.get_messages(chat_id, limit=20)
            
            # Look for simple numeric messages that might be units
            for msg in recent_messages:
                if not msg.message:
                    continue
                    
                # Check for simple numeric content
                if re.match(r'^\s*(\d{2,4})\s*$', msg.message):
                    units = msg.message.strip()
                    if 50 <= int(units) <= 15000:
                        logger.info(f"Found units in message: {units}")
                        updated_text = format_response(provider, card_number, units)
                        await client.edit_message(DESTINATION_CHANNEL, message_id, updated_text)
                        
                        if card_number in pending_validations:
                            del pending_validations[card_number]
                        return
            
            # If no simple numeric message found, try Gemini
            recent_text = "\n".join([msg.message or "" for msg in recent_messages if msg.message])
            units = await get_units_from_gemini(card_number, recent_text, None)  # Don't pass chat_id to avoid fetching messages again
            
            if units != "Unknown":
                logger.info(f"Gemini found units: {units}")
                updated_text = format_response(provider, card_number, units)
                await client.edit_message(DESTINATION_CHANNEL, message_id, updated_text)
                
                if card_number in pending_validations:
                    del pending_validations[card_number]
                return
                
        except Exception as e:
            logger.error(f"Error in check_for_units: {e}")
        
        # Wait before checking again
        await asyncio.sleep(5)
    
    # Time's up, set to Unknown
    try:
        logger.info(f"Validation timeout for {card_number}, setting to Unknown")
        updated_text = format_response(provider, card_number, "Unknown")
        await client.edit_message(DESTINATION_CHANNEL, message_id, updated_text)
    except Exception as e:
        logger.error(f"Error updating message after timeout: {e}")
    
    if card_number in pending_validations:
        del pending_validations[card_number]

def store_card(card_number: str, provider: str, units: str, source_channel: str) -> None:
    """Store card information in the database."""
    try:
        # Normalize the card number to ensure consistent storage
        normalized_card = card_number.strip().replace(" ", "")
        
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        # Check if the card already exists
        cursor.execute("SELECT id FROM cards WHERE card_number = ?", (normalized_card,))
        existing = cursor.fetchone()
        
        if existing:
            # Update existing record
            cursor.execute(
                "UPDATE cards SET provider = ?, units = ?, source_channel = ?, timestamp = ? WHERE card_number = ?",
                (provider, units, source_channel, int(time.time()), normalized_card)
            )
            logger.info(f"Updated existing card: {normalized_card}")
        else:
            # Insert new record
            cursor.execute(
                "INSERT INTO cards (card_number, provider, units, source_channel, timestamp) VALUES (?, ?, ?, ?, ?)",
                (normalized_card, provider, units, source_channel, int(time.time()))
            )
            logger.info(f"Stored new card: {normalized_card}")
        
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error storing card: {e}")

def is_card_duplicate(card_number: str) -> bool:
    """Check if a card has already been processed and stored in the database."""
    try:
        # Normalize the card number to ensure consistent matching
        normalized_card = card_number.strip().replace(" ", "")
        
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        
        # Query the database for this card number
        cursor.execute("SELECT id FROM cards WHERE card_number = ?", (normalized_card,))
        result = cursor.fetchone()
        
        conn.close()
        
        # If we found a result, the card is a duplicate
        is_duplicate = result is not None
        logger.info(f"Duplicate check for {normalized_card}: {'Duplicate' if is_duplicate else 'New card'}")
        return is_duplicate
    except Exception as e:
        logger.error(f"Error checking for duplicate card: {e}")
        return False  # If there's an error, assume it's not a duplicate to be safe

async def handler(event):
    """Process incoming messages, extract card data, and forward to destination."""
    try:
        if not event.message or not event.message.message:
            return
        
        text = event.message.message
        chat_id = event.chat_id
        source_channel = (await event.get_chat()).title or str(chat_id)
        
        logger.info(f"Processing message from {source_channel}: {text[:100]}...")
        
        # First check if the message contains any card patterns
        has_card_pattern = any([
            VODAFONE_PATTERN.search(text),
            WE_PATTERN.search(text),
            ORANGE_PATTERN.search(text),
            "#10*" in text,
            EMBEDDED_CARD_PATTERN.search(text),
            RAW_CARD_PATTERN.search(text),
            MULTI_CARD_PATTERN.search(text),
            re.search(r'#(\d+)\*858\*', text),
            re.search(r'كارت', text, re.IGNORECASE)
        ])
        
        if not has_card_pattern:
            logger.debug(f"No card patterns found in message, skipping")
            return
            
        # Process the message to extract card information
        formatted_responses = await determine_provider_and_format(text, source_channel, chat_id)
        
        if formatted_responses:
            for response in formatted_responses:
                try:
                    # Check if this card has already been processed
                    if is_card_duplicate(response["card_number"]):
                        logger.warning(f"Skipping duplicate card: {response['card_number']}")
                        continue
                    
                    # Send the message
                    sent_message = await client.send_message(DESTINATION_CHANNEL, response["text"])
                    
                    # Store in database
                    store_card(
                        response["card_number"],
                        response["provider"],
                        response["units"],
                        source_channel
                    )
                    
                    logger.info(f"Successfully forwarded {response['provider']} card from {source_channel}")
                    
                    # If units are "Validating...", start the validation timer
                    if response["units"] == "Validating...":
                        # Use a separate task for validation to avoid blocking
                        asyncio.create_task(
                            start_validation_timer(
                                sent_message.id, 
                                response["card_number"], 
                                chat_id,
                                response["provider"]
                            )
                        )
                except Exception as e:
                    logger.error(f"Error sending individual card: {e}")
        else:
            logger.info(f"No card data extracted from message")
    except Exception as e:
        logger.error(f"Error in handler: {e}")
        logger.error(traceback.format_exc())

async def resolve_channel(client, channel_name: str) -> bool:
    """Check if a channel can be resolved by the client."""
    try:
        await client.get_input_entity(channel_name)
        return True
    except (ValueError, telethon.errors.rpcerrorlist.UsernameNotOccupiedError) as e:
        logger.warning(f"Could not resolve channel '{channel_name}': {e}")
        return False

async def load_config(client) -> tuple[List[str], str, int, Dict[str, str]]:
    """Load configuration from SQLite or environment variables, validating channels."""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    c.execute("SELECT channel_name FROM channels WHERE is_source = 1")
    source_channels = [row[0] for row in c.fetchall()]
    if not source_channels:
        default_channels = os.getenv('SOURCE_CHANNELS', '').split(',')
        if not default_channels or default_channels == ['']:
            default_channels = []
        for ch in default_channels:
            if ch.strip():
                c.execute("INSERT OR IGNORE INTO channels (channel_name, is_source) VALUES (?, 1)", (ch.strip(),))
        source_channels = default_channels
    
    valid_source_channels = []
    for ch in source_channels:
        if ch and await resolve_channel(client, ch):
            valid_source_channels.append(ch)
        else:
            logger.warning(f"Skipping invalid source channel: {ch}")
    
    if not valid_source_channels:
        logger.error("No valid source channels found. Please configure valid channels.")
        raise ValueError("No valid source channels available")
    
    c.execute("SELECT channel_name FROM channels WHERE is_source = 0 LIMIT 1")
    dest = c.fetchone()
    destination_channel = dest[0] if dest else os.getenv('DESTINATION_CHANNEL', 'Deploy2')
    if not dest:
        c.execute("INSERT OR IGNORE INTO channels (channel_name, is_source) VALUES (?, 0)", (destination_channel,))
    
    if not await resolve_channel(client, destination_channel):
        logger.error(f"Destination channel '{destination_channel}' is invalid.")
        raise ValueError(f"Invalid destination channel: {destination_channel}")
    
    c.execute("SELECT key, value FROM settings")
    settings = dict(c.fetchall())
    delete_timeout = int(settings.get('delete_timeout', 120))
    emojis = json.loads(settings.get('emojis', '{"vodafone": "🔴", "we": "🟣", "orange": "🟠"}'))
    
    conn.commit()
    conn.close()
    
    return valid_source_channels, destination_channel, delete_timeout, emojis

async def get_units_from_gemini(card_number: str, message_context: str, chat_id: str) -> str:
    """Query Gemini AI to extract units with reduced context from message history."""
    if not GEMINI_API_KEY:
        logger.warning("Gemini API key missing. Returning 'Unknown'.")
        return "Unknown"
    
    logger.info(f"Attempting to extract units using Gemini for card {card_number}")
    
    # Fetch up to 5 messages (4 previous + current) for additional context
    extended_context = message_context
    if chat_id is not None:
        try:
            messages = await client.get_messages(chat_id, limit=5)
            extended_context = "\n".join([msg.message or "" for msg in messages if msg.message])
            logger.debug(f"Extended context length: {len(extended_context)} characters")
        except Exception as e:
            logger.warning(f"Failed to fetch message history: {e}. Using only current message.")
    else:
        logger.info("No chat_id provided, using only the current message context")
    
    # Create a shorter prompt for better performance
    shortened_prompt = f"""
    Extract the units value associated with card {card_number} from this message:
    
    {message_context[:1000]}  # Limit context to 1000 chars
    
    Units are typically numbers between 50 and 15000, often labeled with words like 'وحدة', 'وحده', 'وحدات', 'unit', 'value'.
    For Vodafone sharing messages (containing phrases like "ليك يعني X وحدة Y ضعف تبعتهم لZ"), calculate: (base_unit × friends_multiplier ÷ num_friends).
    For Orange sharing (containing "ابعت X ميجا ل Y"), calculate: total_units ÷ num_friends.
    For direct Vodafone units (containing "معاك X وحدة من كارت فودافون"), calculate: raw_units × 5 ÷ 50.
    
    Return ONLY the numeric value or 'Unknown'. No explanations.
    """
    
    try:
        logger.debug(f"Sending prompt to Gemini: {shortened_prompt[:100]}...")
        model = genai.GenerativeModel(GEMINI_MODEL)
        
        # Set a timeout for the API call
        response = await asyncio.wait_for(
            asyncio.to_thread(model.generate_content, shortened_prompt),
            timeout=10.0  # 10 second timeout
        )
        
        units = response.text.strip()
        logger.info(f"Gemini returned: '{units}' for card {card_number}")
        
        # Validate the response
        if units.isdigit() and 50 <= int(units) <= 15000:
            return units
        else:
            logger.warning(f"Gemini returned invalid units value: '{units}'. Falling back to 'Unknown'.")
            return "Unknown"
    except asyncio.TimeoutError:
        logger.error("Gemini API call timed out after 10 seconds")
        return "Unknown"
    except Exception as e:
        logger.error(f"Failed to query Gemini API: {str(e)}")
        return "Unknown"

async def test_gemini():
    """Test function to verify Gemini API is working."""
    if not GEMINI_API_KEY:
        logger.error("Cannot test Gemini: API key not set")
        return
    
    test_message = """
    كارت شحن 315 وحده 🔥
    📌 كود الشحن: *858*4102550427511#
    🔄 متاح للشحن: 63 مرات
    """
    
    try:
        logger.info("Testing Gemini API with a sample message...")
        # Don't try to fetch message history for the test - pass None instead of "test"
        units = await get_units_from_gemini("*858*4102550427511#", test_message, None)
        logger.info(f"Gemini test result: {units}")
        if units == "Unknown":
            logger.warning("Gemini test returned 'Unknown'. API might not be working correctly.")
        else:
            logger.info("Gemini test successful!")
    except Exception as e:
        logger.error(f"Gemini test failed with error: {e}")

# Add this function to handle graceful shutdown
async def shutdown(signal_received=None):
    """Handle graceful shutdown of the application."""
    global is_shutting_down
    
    if is_shutting_down:
        return  # Prevent multiple shutdown calls
    
    is_shutting_down = True
    logger.info("Shutting down gracefully...")
    
    # Save any pending data
    try:
        # Close database connections
        conn = sqlite3.connect(DB_FILE)
        conn.close()
        logger.info("Database connections closed")
        
        # Cancel any pending tasks except the current one
        tasks = [t for t in asyncio.all_tasks() if t is not asyncio.current_task()]
        for task in tasks:
            task.cancel()
        
        # Wait for all tasks to complete with a timeout
        if tasks:
            await asyncio.wait(tasks, timeout=5)
        
        # Disconnect the client properly
        if client.is_connected():
            await client.disconnect()
            logger.info("Telegram client disconnected")
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")
    
    logger.info("Shutdown complete")

# Modify the main function to handle signals
async def main():
    """Main loop with reconnection handling and signal handling."""
    init_db()
    
    # Set up signal handlers for graceful shutdown
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            sig, lambda sig=sig: asyncio.create_task(shutdown(sig))
        )
    
    try:
        while True and not is_shutting_down:
            try:
                await client.start()
                logger.info("Client started successfully")
                
                # Test Gemini API on startup
                await test_gemini()
                
                global SOURCE_CHANNELS, DESTINATION_CHANNEL, DELETE_TIMEOUT, EMOJIS
                SOURCE_CHANNELS, DESTINATION_CHANNEL, DELETE_TIMEOUT, EMOJIS = await load_config(client)
                
                client.add_event_handler(handler, events.NewMessage(chats=SOURCE_CHANNELS))
                
                logger.info(f"Monitoring source channels: {SOURCE_CHANNELS}")
                logger.info(f"Forwarding to destination: {DESTINATION_CHANNEL}")
                
                # Use a different approach to wait for disconnection
                try:
                    while client.is_connected() and not is_shutting_down:
                        await asyncio.sleep(1)
                except asyncio.CancelledError:
                    # This is expected during shutdown
                    logger.info("Main loop cancelled during shutdown")
                
                if is_shutting_down:
                    break
            except Exception as e:
                if is_shutting_down:
                    break
                logger.error(f"Connection lost: {e}")
                await asyncio.sleep(5)
    finally:
        # Ensure shutdown is called if we exit the loop
        if not is_shutting_down:
            await shutdown()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        # This handles Ctrl+C in the main thread
        logger.info("Received keyboard interrupt")
    except asyncio.CancelledError:
        # This is expected during shutdown
        logger.info("Main task cancelled")
    except Exception as e:
        logger.error(f"Unhandled exception: {e}")
        logger.error(traceback.format_exc())