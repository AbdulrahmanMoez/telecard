import os
import re
import json
import sqlite3
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Union

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters
import psutil
import subprocess
from telegram.constants import ParseMode
from telegram.helpers import escape_markdown
import matplotlib.pyplot as plt
import io
import numpy as np
import csv

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Configuration
admin_ids_str = os.environ.get("ADMIN_IDS", "2021167403")
logger.info(f"Raw ADMIN_IDS env var: '{admin_ids_str}'")
ADMIN_IDS = []
if admin_ids_str:
    try:
        ADMIN_IDS = [int(id.strip()) for id in admin_ids_str.split(",") if id.strip()]
    except Exception as e:
        logger.error(f"Error parsing admin IDs: {e}")
logger.info(f"Parsed admin IDs: {ADMIN_IDS}")
BOT_TOKEN = os.environ.get("ADMIN_BOT_TOKEN", "7550571748:AAEI1U87lUmn1uQdTkRq5DRZNgt1x6qo0eE")
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cards.db")
CONFIG_PATH = os.environ.get("CONFIG_PATH", "config.json")

# Global variables
config = {
    "forwarding_active": True,
    "source_channels": [],
    "destination_channels": [],
    "validation_timeout": 60,
    "settings": {
        "remove_links": True,
        "remove_usernames": True,
        "remove_phone_numbers": True,
        "add_source_attribution": True
    }
}

# Load configuration
def load_config():
    global config
    try:
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, 'r') as f:
                config = json.load(f)
            logger.info("Configuration loaded successfully")
    except Exception as e:
        logger.error(f"Error loading configuration: {e}")

# Save configuration
def save_config():
    try:
        with open(CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=4)
        logger.info("Configuration saved successfully")
    except Exception as e:
        logger.error(f"Error saving configuration: {e}")

# Database functions
def get_db_connection():
    """Get a connection to the SQLite database."""
    try:
        conn = sqlite3.connect(DB_PATH)
        return conn
    except Exception as e:
        logger.error(f"Error connecting to database: {e}")
        raise

def get_card_count():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM cards")
        count = cursor.fetchone()[0]
        conn.close()
        return count
    except Exception as e:
        logger.error(f"Error getting card count: {e}")
        return 0

# Add this function to format cards for easy copying
def format_card_for_display(card):
    """Format a card record for display with copyable card number."""
    card_id, card_number, provider, units, source, timestamp = card
    
    # Format the timestamp
    date_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
    
    # Make the card number easily copyable by putting it on its own line
    return f"📋 `{card_number}`\n🔹 Provider: {provider}\n🔹 Units: {units}\n🔹 Source: {source}\n🔹 Date: {date_str}"

# Update the get_recent_cards function to use the new format
def get_recent_cards(limit=5):
    """Get the most recent cards from the database."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, card_number, provider, units, source_channel, timestamp FROM cards ORDER BY timestamp DESC LIMIT ?",
            (limit,)
        )
        cards = cursor.fetchall()
        conn.close()
        
        return [format_card_for_display(card) for card in cards]
    except Exception as e:
        logger.error(f"Error getting recent cards: {e}")
        return []

def clear_card_database():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM cards")
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Error clearing card database: {e}")
        return False

# Helper functions
def is_admin(user_id):
    return user_id in ADMIN_IDS

# Command handlers
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send main menu when the command /start is issued."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await update.message.reply_text("Unauthorized access.")
        return
    
    await show_main_menu(update, context)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show the main menu with database statistics."""
    # Get database stats
    stats = get_card_stats()
    
    status_text = "✅ Active" if config["forwarding_active"] else "❌ Inactive"
    
    message_text = f"""
🤖 Card Forwarding Bot Admin Panel

Current Status: {status_text}
📊 Database: {stats["total"]} total cards
📈 Last 24h: {stats["last_24h"]} cards
📅 Last 7d: {stats["last_7d"]} cards

Select an option:
"""
    
    keyboard = [
        [InlineKeyboardButton("📊 Status", callback_data="status"),
         InlineKeyboardButton("⚙️ Settings", callback_data="settings")],
        [InlineKeyboardButton("📋 Manage Sources", callback_data="manage_sources"),
         InlineKeyboardButton("📤 Manage Destinations", callback_data="manage_destinations")],
        [InlineKeyboardButton("💾 Database", callback_data="database")]
    ]
    
    if config["forwarding_active"]:
        keyboard.append([InlineKeyboardButton("⏹️ Stop Forwarding", callback_data="stop_forwarding")])
    else:
        keyboard.append([InlineKeyboardButton("▶️ Start Forwarding", callback_data="start_forwarding")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(message_text, reply_markup=reply_markup)

# Add this function to check if the main bot is running
def is_main_bot_running():
    """Check if the main forwarding bot process is running."""
    try:
        # Look for Python processes running main.py
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                # Check if this is a Python process running main.py
                if proc.info['name'] == 'python' or proc.info['name'] == 'python3':
                    cmdline = proc.info['cmdline']
                    if cmdline and any('main.py' in arg for arg in cmdline):
                        return True, proc.pid
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return False, None
    except Exception as e:
        logger.error(f"Error checking if main bot is running: {e}")
        return False, None

async def show_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Display detailed status information."""
    status_text = "✅ Active" if config["forwarding_active"] else "❌ Inactive"
    
    # Check if the main bot is running
    main_bot_running, pid = is_main_bot_running()
    bot_status = f"✅ Running (PID: {pid})" if main_bot_running else "❌ Not Running"
    
    # Get recent cards
    recent_cards = get_recent_cards(5)
    recent_cards_text = "\n\n".join(recent_cards) if recent_cards else "No recent cards"
    
    message_text = f"""
📊 Bot Status

Forwarding: {status_text}
Main Bot: {bot_status}
Sources: {len(config['source_channels'])}
Destinations: {len(config['destination_channels'])}
Cards in Database: {get_card_count()}
Validation Timeout: {config.get('validation_timeout', 60)} seconds

Recent Cards:
{recent_cards_text}
"""
    
    keyboard = [
        [InlineKeyboardButton("🔄 Refresh Status", callback_data="status")],
        [InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")]
    ]
    
    if not main_bot_running:
        keyboard.insert(0, [InlineKeyboardButton("▶️ Start Main Bot", callback_data="start_main_bot")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Use Markdown parsing for the code blocks
    await update.callback_query.edit_message_text(
        message_text, 
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )

async def get_user_channels(context):
    """Get all channels and groups the bot is a member of."""
    try:
        # This is a placeholder - in a real implementation, you would use
        # the Telegram client to get the dialogs
        # Since python-telegram-bot doesn't expose this directly, we'll simulate it
        
        # In a real implementation, you might need to use telethon or pyrogram
        # alongside python-telegram-bot to get this information
        
        # For now, return a sample list
        return [
            {"id": "123456789", "title": "Sample Channel 1", "type": "channel", "username": "sample1"},
            {"id": "987654321", "title": "Sample Group 1", "type": "group", "username": None},
            # Add more sample channels as needed
        ]
    except Exception as e:
        logger.error(f"Error getting user channels: {e}")
        return []

def get_invalid_sources():
    """Get sources that are no longer valid (bot not a member)."""
    # This would require checking each source against the bot's dialogs
    # For now, we'll just return a placeholder
    return []

async def browse_channels(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show a list of channels the bot is in but not configured as source/destination."""
    try:
        # Show loading message
        await update.callback_query.edit_message_text(
            "🔍 Loading channels... This may take a moment.",
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Get all channels the bot is in
        all_channels = await get_user_channels(context)
        
        if not all_channels:
            await update.callback_query.edit_message_text(
                "No channels found. The bot might not be a member of any channels.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="manage_sources")]]),
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Filter out channels already in sources or destinations
        available_channels = []
        for channel in all_channels:
            channel_id = str(channel["id"])
            
            # Check if this channel is already configured
            if (channel_id not in config["source_channels"] and 
                channel_id not in config["destination_channels"]):
                available_channels.append(channel)
        
        if not available_channels:
            await update.callback_query.edit_message_text(
                "No additional channels available. All your channels are already configured.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="manage_sources")]]),
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Create a paginated list of channels
        context.user_data["available_channels"] = available_channels
        context.user_data["channel_page"] = 0
        await show_channel_page(update, context)
        
    except Exception as e:
        logger.error(f"Error browsing channels: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error loading channels: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="manage_sources")]]),
            parse_mode=ParseMode.MARKDOWN
        )

async def show_channel_page(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show a paginated list of available channels."""
    available_channels = context.user_data.get("available_channels", [])
    page = context.user_data.get("channel_page", 0)
    
    # 5 channels per page
    channels_per_page = 5
    start_idx = page * channels_per_page
    end_idx = min(start_idx + channels_per_page, len(available_channels))
    
    message_text = "**Available Channels**\n\nSelect a channel to add as source or destination:\n\n"
    
    keyboard = []
    
    # Add channel buttons
    for i in range(start_idx, end_idx):
        channel = available_channels[i]
        channel_title = channel["title"]
        channel_type = channel["type"].capitalize()
        channel_id = channel["id"]
        
        message_text += f"{i+1}. {channel_title} ({channel_type})\n"
        
        # Add buttons to add as source or destination
        keyboard.append([
            InlineKeyboardButton(f"Add as Source", callback_data=f"add_source_{channel_id}"),
            InlineKeyboardButton(f"Add as Dest", callback_data=f"add_dest_{channel_id}")
        ])
    
    # Add navigation buttons
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("⬅️ Previous", callback_data="prev_channel_page"))
    
    if end_idx < len(available_channels):
        nav_buttons.append(InlineKeyboardButton("➡️ Next", callback_data="next_channel_page"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    # Add back button
    keyboard.append([InlineKeyboardButton("◀️ Back", callback_data="manage_sources")])
    
    # Show the page
    try:
        await update.callback_query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error showing channel page: {e}")
        # Try without parse mode
        await update.callback_query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def show_invalid_sources(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show a list of invalid sources for easy removal."""
    invalid_sources = get_invalid_sources()
    
    if not invalid_sources:
        await update.callback_query.edit_message_text(
            "✅ All configured sources are valid.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="manage_sources")]]),
            parse_mode=ParseMode.MARKDOWN
        )
        return
    
    message_text = "**Invalid Sources**\n\nThese sources are no longer valid (bot not a member). Select to remove:\n\n"
    
    keyboard = []
    
    # Add buttons for each invalid source
    for i, source in enumerate(invalid_sources):
        keyboard.append([InlineKeyboardButton(f"❌ Remove {source}", callback_data=f"remove_invalid_{i}")])
    
    # Add back button
    keyboard.append([InlineKeyboardButton("◀️ Back", callback_data="manage_sources")])
    
    await update.callback_query.edit_message_text(
        message_text,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN
    )

# Enhanced settings section
async def show_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show enhanced settings menu."""
    # Get current settings
    settings = config.get("settings", {})
    validation_timeout = config.get("validation_timeout", 60)
    
    # Format settings status
    remove_links = "✅ ON" if settings.get("remove_links", True) else "❌ OFF"
    remove_usernames = "✅ ON" if settings.get("remove_usernames", True) else "❌ OFF"
    remove_phone_numbers = "✅ ON" if settings.get("remove_phone_numbers", True) else "❌ OFF"
    add_source_attribution = "✅ ON" if settings.get("add_source_attribution", True) else "❌ OFF"
    
    message_text = f"""
⚙️ **Bot Settings**

**Content Filtering:**
• Remove Links: {remove_links}
• Remove Usernames: {remove_usernames}
• Remove Phone Numbers: {remove_phone_numbers}
• Add Source Attribution: {add_source_attribution}

**Validation Settings:**
• Timeout: {validation_timeout} seconds

**System Settings:**
• Database Size: {get_db_size_formatted()}
• Card Count: {get_card_count()}
"""
    
    keyboard = [
        # Content filtering toggles
        [InlineKeyboardButton("Toggle Links Filter", callback_data="toggle_links"),
         InlineKeyboardButton("Toggle Usernames Filter", callback_data="toggle_usernames")],
        [InlineKeyboardButton("Toggle Phone Numbers Filter", callback_data="toggle_phones"),
         InlineKeyboardButton("Toggle Source Attribution", callback_data="toggle_attribution")],
        
        # Validation settings
        [InlineKeyboardButton("Set Validation Timeout", callback_data="set_validation_timeout")],
        
        # System settings
        [InlineKeyboardButton("🔄 Restart Bot", callback_data="restart_bot"),
         InlineKeyboardButton("💾 Backup Database", callback_data="backup_database")],
        
        # Back button
        [InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)

def get_db_size_formatted():
    """Get the database size in a human-readable format."""
    try:
        size_bytes = os.path.getsize(DB_PATH)
        if size_bytes < 1024:
            return f"{size_bytes} bytes"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.2f} KB"
        else:
            return f"{size_bytes / (1024 * 1024):.2f} MB"
    except Exception as e:
        logger.error(f"Error getting DB size: {e}")
        return "Unknown"

# Update the manage_sources function to include the new buttons
async def manage_sources(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show the sources management menu with enhanced options and auto-cleanup."""
    try:
        # Auto-remove invalid sources
        invalid_sources = await auto_remove_invalid_sources(context)
        
        sources = config["source_channels"]
        
        message_text = "📋 Source Channels Management\n\n"
        
        # Show notification if invalid sources were removed
        if invalid_sources:
            message_text += f"⚠️ Automatically removed {len(invalid_sources)} invalid sources.\n\n"
        
        if sources:
            message_text += "Current source channels:\n"
            for i, source in enumerate(sources):
                # Format each source with a red X button emoji
                message_text += f"❌ Remove {source}\n"
        else:
            message_text += "No source channels configured.\n"
        
        keyboard = []
        
        # Add action buttons at the top
        keyboard.append([
            InlineKeyboardButton("➕ Add Sources", callback_data="add_sources"),
            InlineKeyboardButton("🔍 Browse Channels", callback_data="browse_channels")
        ])
        
        # Add remove buttons for each source
        if sources:
            for i, source in enumerate(sources):
                keyboard.append([InlineKeyboardButton(f"❌ Remove {source}", callback_data=f"remove_source_{i}")])
        
        # Add back button
        keyboard.append([InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # Debug logging
        logger.info(f"Showing sources menu with {len(sources)} sources")
        
        await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in manage_sources: {e}")
        await update.callback_query.edit_message_text(
            f"Error displaying sources: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")]])
        )

# Fix the button callback handler to ensure all buttons work properly
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button callbacks with enhanced database functionality."""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    # Main menu options
    if data == "main_menu":
        await show_main_menu(update, context)
    elif data == "status":
        await show_status(update, context)
    elif data == "settings":
        await show_settings(update, context)
    elif data == "start_forwarding":
        config["forwarding_active"] = True
        save_config()
        await show_main_menu(update, context)
    elif data == "stop_forwarding":
        config["forwarding_active"] = False
        save_config()
        await show_main_menu(update, context)
    elif data == "manage_sources":
        await manage_sources(update, context)
    elif data == "manage_destinations":
        await manage_destinations(update, context)
    elif data == "database":
        await manage_database(update, context)
    
    # Database management options
    elif data == "view_recent_cards":
        await view_recent_cards(update, context)
    elif data == "export_database":
        await export_database_handler(update, context)
    elif data == "clean_old_records":
        await clean_old_records_handler(update, context)
    elif data == "confirm_clean_old":
        await confirm_clean_old_records(update, context)
    elif data == "clear_database":
        await clear_database_handler(update, context)
    elif data == "confirm_clear_db":
        await confirm_clear_database(update, context)
    
    # Enhanced channel management
    elif data == "browse_channels":
        await browse_channels(update, context)
    elif data == "check_invalid_sources":
        await show_invalid_sources(update, context)
    elif data == "prev_channel_page":
        context.user_data["channel_page"] = max(0, context.user_data.get("channel_page", 0) - 1)
        await show_channel_page(update, context)
    elif data == "next_channel_page":
        context.user_data["channel_page"] = context.user_data.get("channel_page", 0) + 1
        await show_channel_page(update, context)
    
    # Settings toggles
    elif data == "toggle_links":
        settings = config.get("settings", {})
        settings["remove_links"] = not settings.get("remove_links", True)
        config["settings"] = settings
        save_config()
        await show_settings(update, context)
    elif data == "toggle_usernames":
        settings = config.get("settings", {})
        settings["remove_usernames"] = not settings.get("remove_usernames", True)
        config["settings"] = settings
        save_config()
        await show_settings(update, context)
    elif data == "toggle_phones":
        settings = config.get("settings", {})
        settings["remove_phone_numbers"] = not settings.get("remove_phone_numbers", True)
        config["settings"] = settings
        save_config()
        await show_settings(update, context)
    elif data == "toggle_attribution":
        settings = config.get("settings", {})
        settings["add_source_attribution"] = not settings.get("add_source_attribution", True)
        config["settings"] = settings
        save_config()
        await show_settings(update, context)
    
    # Handle adding channels from browse
    elif data.startswith("add_source_"):
        channel_id = data.replace("add_source_", "")
        available_channels = context.user_data.get("available_channels", [])
        
        # Find the channel in available_channels
        for channel in available_channels:
            if str(channel["id"]) == channel_id:
                channel_title = channel["title"]
                
                # Add to sources if not already there
                if channel_id not in config["source_channels"]:
                    config["source_channels"].append(channel_id)
                    save_config()
                    await query.edit_message_text(
                        f"✅ Added {channel_title} to sources",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🔍 Continue Browsing", callback_data="browse_channels")],
                            [InlineKeyboardButton("◀️ Back to Sources", callback_data="manage_sources")]
                        ])
                    )
                    return
        
        # If we get here, something went wrong
        await query.edit_message_text(
            "❌ Error adding channel to sources",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="browse_channels")]])
        )
    
    elif data.startswith("add_dest_"):
        channel_id = data.replace("add_dest_", "")
        available_channels = context.user_data.get("available_channels", [])
        
        # Find the channel in available_channels
        for channel in available_channels:
            if str(channel["id"]) == channel_id:
                channel_title = channel["title"]
                
                # Add to destinations if not already there
                if channel_id not in config["destination_channels"]:
                    config["destination_channels"].append(channel_id)
                    save_config()
                    await query.edit_message_text(
                        f"✅ Added {channel_title} to destinations",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🔍 Continue Browsing", callback_data="browse_channels")],
                            [InlineKeyboardButton("◀️ Back to Sources", callback_data="manage_sources")]
                        ])
                    )
                    return
        
        # If we get here, something went wrong
        await query.edit_message_text(
            "❌ Error adding channel to destinations",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="browse_channels")]])
        )
    
    # Handle removing sources
    elif data.startswith("remove_source_"):
        index = int(data.replace("remove_source_", ""))
        if 0 <= index < len(config["source_channels"]):
            removed = config["source_channels"].pop(index)
            save_config()
            await query.edit_message_text(
                f"✅ Removed source: {removed}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="manage_sources")]])
            )
        else:
            await query.edit_message_text(
                "❌ Error: Invalid source index",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="manage_sources")]])
            )
    
    # Handle other callbacks
    else:
        await query.edit_message_text(
            f"Unhandled callback: {data}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")]])
        )

# Enhanced database management with auto-clean notification
async def manage_database(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show database management options with improved icons."""
    # Check if auto-clean was performed
    auto_cleaned = context.user_data.get("auto_cleaned", 0)
    auto_clean_msg = f"\n\n Auto-cleaned {auto_cleaned} old records." if auto_cleaned else ""
    
    message_text = f"""
💾 Database Management

📊 Current database size: {get_db_size_formatted()}
🔢 Total cards: {get_card_count()}{auto_clean_msg}

Select an option:
"""
    
    keyboard = [
        [InlineKeyboardButton("👁️ View Recent Cards", callback_data="view_recent_cards"),
         InlineKeyboardButton("📤 Export Database", callback_data="export_database")],
        [InlineKeyboardButton("🧹 Clean Old Records", callback_data="clean_old_records"),
         InlineKeyboardButton("🗑️ Clear All Data", callback_data="clear_database")],
        [InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")]
    ]
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup)

# Implement the database action handlers
async def view_recent_cards(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show recent cards with copyable card numbers."""
    try:
        # Get recent cards (more than in status)
        recent_cards = get_recent_cards(10)
        
        if not recent_cards:
            await update.callback_query.edit_message_text(
                "No cards found in the database.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]]),
            )
            return
        
        message_text = "📋 Recent Cards (click card number to copy):\n\n"
        message_text += "\n\n".join(recent_cards)
        
        keyboard = [
            [InlineKeyboardButton("🔄 Refresh", callback_data="view_recent_cards")],
            [InlineKeyboardButton("◀️ Back", callback_data="database")]
        ]
        
        await update.callback_query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error viewing recent cards: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error viewing cards: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )

async def export_database_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Export the database to CSV and send it."""
    try:
        await update.callback_query.edit_message_text(
            "📤 Exporting database... Please wait.",
            reply_markup=None
        )
        
        # Export database to CSV
        csv_file = export_database_to_csv()
        
        # Send the file
        await context.bot.send_document(
            chat_id=update.effective_chat.id,
            document=csv_file,
            filename=f"cards_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            caption="📊 Database Export"
        )
        
        # Return to database menu
        await manage_database(update, context)
    except Exception as e:
        logger.error(f"Error exporting database: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error exporting database: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )

async def clean_old_records_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clean records older than 30 days."""
    try:
        # Ask for confirmation
        message_text = "⚠️ Are you sure you want to delete all records older than 30 days?"
        
        keyboard = [
            [InlineKeyboardButton("✅ Yes, clean old records", callback_data="confirm_clean_old")],
            [InlineKeyboardButton("❌ No, cancel", callback_data="database")]
        ]
        
        await update.callback_query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        logger.error(f"Error in clean_old_records_handler: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )

async def confirm_clean_old_records(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Confirm and execute cleaning of old records."""
    try:
        await update.callback_query.edit_message_text(
            "🧹 Cleaning old records... Please wait.",
            reply_markup=None
        )
        
        # Clean records older than 30 days
        deleted_count = await clean_old_records(30)
        
        await update.callback_query.edit_message_text(
            f"✅ Successfully cleaned {deleted_count} old records.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )
    except Exception as e:
        logger.error(f"Error cleaning old records: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error cleaning old records: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )

async def clear_database_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Clear all records from the database."""
    try:
        # Ask for confirmation
        message_text = "⚠️ WARNING: Are you sure you want to delete ALL records from the database?\n\nThis action cannot be undone!"
        
        keyboard = [
            [InlineKeyboardButton("⚠️ Yes, delete EVERYTHING", callback_data="confirm_clear_db")],
            [InlineKeyboardButton("❌ No, cancel", callback_data="database")]
        ]
        
        await update.callback_query.edit_message_text(
            message_text,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        logger.error(f"Error in clear_database_handler: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )

async def confirm_clear_database(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Confirm and execute clearing of all database records."""
    try:
        await update.callback_query.edit_message_text(
            "🗑️ Clearing database... Please wait.",
            reply_markup=None
        )
        
        # Clear all records
        deleted_count = await clear_database()
        
        await update.callback_query.edit_message_text(
            f"✅ Successfully cleared {deleted_count} records from the database.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )
    except Exception as e:
        logger.error(f"Error clearing database: {e}")
        await update.callback_query.edit_message_text(
            f"❌ Error clearing database: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back", callback_data="database")]])
        )

# Add a periodic job to run maintenance tasks
async def scheduled_maintenance(context):
    """Run scheduled maintenance tasks."""
    try:
        logger.info("Running scheduled maintenance")
        
        # Auto-remove invalid sources
        invalid_sources = await auto_remove_invalid_sources(context)
        if invalid_sources:
            logger.info(f"Auto-removed {len(invalid_sources)} invalid sources")
        
        # Auto-clean storage
        deleted_count = await auto_clean_storage()
        if deleted_count:
            logger.info(f"Auto-cleaned {deleted_count} old records")
        
        logger.info("Scheduled maintenance completed")
    except Exception as e:
        logger.error(f"Error during scheduled maintenance: {e}")

# Add the missing handle_text_input function
async def handle_text_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text input from users."""
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("Unauthorized access.")
        return
    
    text = update.message.text
    
    # Check if we're waiting for input
    waiting_for = context.user_data.get("waiting_for", None)
    
    if waiting_for == "add_sources":
        # Process adding sources
        sources = [s.strip() for s in text.split(",")]
        valid_sources = []
        
        for source in sources:
            if source and source not in config["source_channels"]:
                config["source_channels"].append(source)
                valid_sources.append(source)
        
        if valid_sources:
            save_config()
            await update.message.reply_text(
                f"✅ Added {len(valid_sources)} source(s): {', '.join(valid_sources)}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back to Sources", callback_data="manage_sources")]])
            )
        else:
            await update.message.reply_text(
                "❌ No valid sources provided or sources already exist.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back to Sources", callback_data="manage_sources")]])
            )
        
        # Clear waiting state
        context.user_data["waiting_for"] = None
    
    elif waiting_for == "add_destinations":
        # Process adding destinations
        destinations = [d.strip() for d in text.split(",")]
        valid_destinations = []
        
        for destination in destinations:
            if destination and destination not in config["destination_channels"]:
                config["destination_channels"].append(destination)
                valid_destinations.append(destination)
        
        if valid_destinations:
            save_config()
            await update.message.reply_text(
                f"✅ Added {len(valid_destinations)} destination(s): {', '.join(valid_destinations)}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back to Destinations", callback_data="manage_destinations")]])
            )
        else:
            await update.message.reply_text(
                "❌ No valid destinations provided or destinations already exist.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Back to Destinations", callback_data="manage_destinations")]])
            )
        
        # Clear waiting state
        context.user_data["waiting_for"] = None
    
    else:
        # If not waiting for specific input, show main menu
        await update.message.reply_text(
            "Please use the buttons to navigate.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")]])
        )

# Add the missing manage_destinations function
async def manage_destinations(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show the destinations management menu."""
    destinations = config["destination_channels"]
    
    message_text = "**Destination Channels Management**\n\n"
    
    if destinations:
        message_text += "Current destination channels:\n"
        for i, destination in enumerate(destinations):
            message_text += f"{i+1}. {destination}\n"
    else:
        message_text += "No destination channels configured.\n"
    
    keyboard = [
        [InlineKeyboardButton("➕ Add Destinations", callback_data="add_destinations")]
    ]
    
    # Add remove buttons for each destination
    if destinations:
        for i, destination in enumerate(destinations):
            keyboard.append([InlineKeyboardButton(f"❌ Remove {destination}", callback_data=f"remove_destination_{i}")])
    
    # Add back button
    keyboard.append([InlineKeyboardButton("◀️ Back to Main Menu", callback_data="main_menu")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.MARKDOWN)

# Add the missing auto_clean_storage function
async def auto_clean_storage():
    """Automatically clean old records from the database."""
    try:
        # Keep only the last 1000 records or records from the last 30 days
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the timestamp for 30 days ago
        thirty_days_ago = int((datetime.now() - timedelta(days=30)).timestamp())
        
        # Delete old records
        cursor.execute(
            "DELETE FROM cards WHERE id NOT IN (SELECT id FROM cards ORDER BY timestamp DESC LIMIT 1000) AND timestamp < ?",
            (thirty_days_ago,)
        )
        
        deleted_count = cursor.rowcount
        conn.commit()
        conn.close()
        
        logger.info(f"Auto-cleaned {deleted_count} old records from database")
        return deleted_count
    except Exception as e:
        logger.error(f"Error during auto-clean: {e}")
        return 0

# Add the missing auto_remove_invalid_sources function
async def auto_remove_invalid_sources(context):
    """Automatically detect and remove invalid sources."""
    try:
        # Get all channels the bot is in
        all_channels = await get_user_channels(context)
        valid_channel_ids = [str(channel["id"]) for channel in all_channels]
        
        # Find invalid sources
        invalid_sources = []
        for source in config["source_channels"]:
            # Check if source is a numeric ID
            if source.isdigit() and source not in valid_channel_ids:
                invalid_sources.append(source)
        
        # Remove invalid sources
        for source in invalid_sources:
            config["source_channels"].remove(source)
        
        if invalid_sources:
            save_config()
            logger.info(f"Auto-removed {len(invalid_sources)} invalid sources: {invalid_sources}")
        
        return invalid_sources
    except Exception as e:
        logger.error(f"Error during auto-remove invalid sources: {e}")
        return []

# Add this function to generate daily reports
async def generate_daily_report():
    """Generate a daily report of card activity."""
    try:
        # Get today's date range
        today = datetime.now().date()
        start_of_day = int(datetime.combine(today, datetime.min.time()).timestamp())
        end_of_day = int(datetime.combine(today, datetime.max.time()).timestamp())
        
        # Connect to database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get today's cards
        cursor.execute(
            "SELECT card_number, provider, units, source_channel, timestamp FROM cards WHERE timestamp >= ? AND timestamp <= ?",
            (start_of_day, end_of_day)
        )
        today_cards = cursor.fetchall()
        
        # Get card count by provider
        cursor.execute(
            "SELECT provider, COUNT(*) FROM cards WHERE timestamp >= ? AND timestamp <= ? GROUP BY provider",
            (start_of_day, end_of_day)
        )
        provider_counts = cursor.fetchall()
        
        # Get card with highest units
        cursor.execute(
            "SELECT card_number, provider, units, source_channel FROM cards WHERE timestamp >= ? AND timestamp <= ? ORDER BY CAST(units AS REAL) DESC LIMIT 1",
            (start_of_day, end_of_day)
        )
        highest_units_card = cursor.fetchone()
        
        # Get hourly distribution
        cursor.execute(
            "SELECT strftime('%H', datetime(timestamp, 'unixepoch')) as hour, COUNT(*) FROM cards WHERE timestamp >= ? AND timestamp <= ? GROUP BY hour",
            (start_of_day, end_of_day)
        )
        hourly_distribution = cursor.fetchall()
        
        conn.close()
        
        # Format the report
        report = f"📊 *Daily Report for {today.strftime('%Y-%m-%d')}*\n\n"
        
        # Total cards
        report += f"*Total Cards Processed:* {len(today_cards)}\n\n"
        
        # Provider breakdown
        if provider_counts:
            report += "*Cards by Provider:*\n"
            for provider, count in provider_counts:
                report += f"• {provider}: {count}\n"
            report += "\n"
        
        # Highest units card
        if highest_units_card:
            card_number, provider, units, source = highest_units_card
            # Mask the card number for security
            masked_number = card_number[:6] + "..." + card_number[-4:] if len(card_number) > 10 else "..."
            report += f"*Highest Units Card:*\n• Provider: {provider}\n• Units: {units}\n• Card: {masked_number}\n\n"
        
        # Generate hourly chart
        if hourly_distribution:
            hours = [0] * 24
            for hour_str, count in hourly_distribution:
                hour = int(hour_str)
                hours[hour] = count
            
            # Create the chart
            plt.figure(figsize=(10, 5))
            plt.bar(range(24), hours, color='skyblue')
            plt.xlabel('Hour of Day')
            plt.ylabel('Number of Cards')
            plt.title('Hourly Card Distribution')
            plt.xticks(range(0, 24, 2))
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            
            # Save chart to buffer
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            
            return report, buf
        
        return report, None
        
    except Exception as e:
        logger.error(f"Error generating daily report: {e}")
        return f"Error generating daily report: {str(e)}", None

# Add this function to send the daily report
async def send_daily_report(context):
    """Send the daily report to all destination channels."""
    try:
        logger.info("Generating daily report")
        
        report_text, chart_buffer = await generate_daily_report()
        
        # Send to all destination channels
        for destination in config["destination_channels"]:
            try:
                # First send the text
                message = await context.bot.send_message(
                    chat_id=destination,
                    text=report_text,
                    parse_mode=ParseMode.MARKDOWN
                )
                
                # Then send the chart if available
                if chart_buffer:
                    await context.bot.send_photo(
                        chat_id=destination,
                        photo=chart_buffer,
                        caption="Hourly Card Distribution"
                    )
                
                logger.info(f"Daily report sent to {destination}")
            except Exception as e:
                logger.error(f"Error sending report to {destination}: {e}")
        
        logger.info("Daily report sending completed")
    except Exception as e:
        logger.error(f"Error in send_daily_report: {e}")

# Add this function to schedule the daily report
async def schedule_daily_report(context):
    """Schedule the daily report to be sent at the end of the day."""
    try:
        # Schedule for 11:55 PM
        now = datetime.now()
        target_time = now.replace(hour=23, minute=55, second=0, microsecond=0)
        
        # If it's already past the target time, schedule for tomorrow
        if now > target_time:
            target_time = target_time + timedelta(days=1)
        
        # Calculate seconds until target time
        seconds_until_target = (target_time - now).total_seconds()
        
        # Schedule the job
        context.job_queue.run_once(send_daily_report, seconds_until_target)
        logger.info(f"Daily report scheduled for {target_time}")
    except Exception as e:
        logger.error(f"Error scheduling daily report: {e}")

# Fix the main function to properly schedule the daily report
def main() -> None:
    """Start the bot with enhanced functionality."""
    # Load configuration
    load_config()
    
    # Initialize database and sync with existing data
    existing_records = init_db()
    logger.info(f"Synced with database: {existing_records} existing records found")
    
    # Create the Application
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_callback))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_input))
    application.add_handler(CommandHandler("send_report", command_send_report))
    
    # Add scheduled maintenance job (run every 24 hours) if job queue is available
    job_queue = application.job_queue
    if job_queue is not None:
        job_queue.run_repeating(scheduled_maintenance, interval=86400, first=10)
        logger.info("Scheduled maintenance job added")
        
        # Schedule the daily report using the job queue instead of create_task
        job_queue.run_once(
            lambda context: asyncio.create_task(schedule_daily_report(context)), 
            when=10  # Run 10 seconds after startup
        )
        logger.info("Daily report scheduling initiated")
    else:
        logger.warning("Job queue not available. Install with: pip install python-telegram-bot[job-queue]")
    
    # Start the Bot
    application.run_polling()
    
    logger.info("Bot started")

# Add a command to manually generate and send a report
async def command_send_report(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Command handler to manually send a daily report."""
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("Unauthorized access.")
        return
    
    await update.message.reply_text("Generating and sending daily report...")
    await send_daily_report(context)
    await update.message.reply_text("Daily report sent!")

# Add this function to export the database to CSV
def export_database_to_csv():
    """Export the cards database to a CSV file."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cards")
        
        # Get column names
        column_names = [description[0] for description in cursor.description]
        
        # Get all rows
        rows = cursor.fetchall()
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow(column_names)
        
        # Write data
        writer.writerows(rows)
        
        conn.close()
        
        # Convert to bytes for sending
        csv_bytes = output.getvalue().encode('utf-8')
        return io.BytesIO(csv_bytes)
    except Exception as e:
        logger.error(f"Error exporting database: {e}")
        raise

# Add these functions to handle database cleaning operations

async def clean_old_records(days=30):
    """Clean records older than specified days."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get timestamp for X days ago
        days_ago = int((datetime.now() - timedelta(days=days)).timestamp())
        
        # Delete old records
        cursor.execute("DELETE FROM cards WHERE timestamp < ?", (days_ago,))
        deleted_count = cursor.rowcount
        
        conn.commit()
        conn.close()
        
        logger.info(f"Cleaned {deleted_count} records older than {days} days")
        return deleted_count
    except Exception as e:
        logger.error(f"Error cleaning old records: {e}")
        raise

async def clear_database():
    """Clear all records from the database."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM cards")
        deleted_count = cursor.rowcount
        
        conn.commit()
        conn.close()
        
        logger.info(f"Cleared all {deleted_count} records from database")
        return deleted_count
    except Exception as e:
        logger.error(f"Error clearing database: {e}")
        raise

# Add this function to initialize the database connection
def init_db():
    """Initialize the database connection and create tables if they don't exist."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # Check if the cards table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cards'")
        if not cursor.fetchone():
            # Create the cards table if it doesn't exist
            cursor.execute('''
            CREATE TABLE cards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                card_number TEXT NOT NULL,
                provider TEXT,
                units TEXT,
                source_channel TEXT,
                timestamp INTEGER
            )
            ''')
            logger.info("Created cards table in database")
        
        # Get the count of existing records
        cursor.execute("SELECT COUNT(*) FROM cards")
        count = cursor.fetchone()[0]
        logger.info(f"Database initialized with {count} existing records")
        
        conn.commit()
        conn.close()
        return count
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        return 0

# Add this function to get card statistics
def get_card_stats():
    """Get statistics about the cards in the database."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        stats = {}
        
        # Total cards
        cursor.execute("SELECT COUNT(*) FROM cards")
        stats["total"] = cursor.fetchone()[0]
        
        # Cards by provider
        cursor.execute("SELECT provider, COUNT(*) FROM cards GROUP BY provider ORDER BY COUNT(*) DESC")
        stats["by_provider"] = cursor.fetchall()
        
        # Cards in the last 24 hours
        yesterday = int((datetime.now() - timedelta(days=1)).timestamp())
        cursor.execute("SELECT COUNT(*) FROM cards WHERE timestamp >= ?", (yesterday,))
        stats["last_24h"] = cursor.fetchone()[0]
        
        # Cards in the last 7 days
        last_week = int((datetime.now() - timedelta(days=7)).timestamp())
        cursor.execute("SELECT COUNT(*) FROM cards WHERE timestamp >= ?", (last_week,))
        stats["last_7d"] = cursor.fetchone()[0]
        
        # First and last card dates
        cursor.execute("SELECT MIN(timestamp), MAX(timestamp) FROM cards")
        min_ts, max_ts = cursor.fetchone()
        if min_ts and max_ts:
            stats["first_card"] = datetime.fromtimestamp(min_ts).strftime('%Y-%m-%d')
            stats["last_card"] = datetime.fromtimestamp(max_ts).strftime('%Y-%m-%d %H:%M:%S')
        
        conn.close()
        return stats
    except Exception as e:
        logger.error(f"Error getting card stats: {e}")
        return {"total": 0, "by_provider": [], "last_24h": 0, "last_7d": 0}

if __name__ == "__main__":
    main()